<header class="header">
    <div class="container container--header">
        <nav class="nav">
            <a href="#!" class="logo">
                <img src="../../img/logo.svg" alt="logo">
            </a>
            <ul class="nav-list">
                <li class="nav-list__item">
                    <a href="../../index.php" class="nav-list__link nav-list__link--active">Delivery Food</a>
                </li>
                <li class="nav-list__item">
                    <a href="list-order.php" class="nav-list__link">Список заказов</a>
                </li>
                <li class="nav-list__item">
                    <a href="tovars-management.php" class="nav-list__link">Управление товарами</a>
                </li>
                <li class="nav-list__item">
                    <a href="category-management.php" class="nav-list__link">Управление категориями</a>
                    
                </li>          
            </ul>         
         </nav>
     </div>
   </header>